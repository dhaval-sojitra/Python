stud=[(1,'abc','rajkot'), (2,'cde','surat'), (3,'efg','goa'), (4,'ghi','diu'), (5,'ijk','vadodara')]
import pandas as pd
df=pd.DataFrame(stud, columns=['roll','name','city'])
print(df)
# Knowing number of rows and columns
print(df.shape)
#Display first five records
print(df.head())
#Display last five records
print(df.tail())
#Display first two records
print(df.head(2))
#Display last two records
print(df.tail(2))
#Retrieving range of rows
print(df[2:5])
#Retrieving data from columns
print(df[['name','city']])
#Finding Maximum values
print(df['roll'].max())
#Finding Minimum values
print(df['roll'].min())
#Display students who belongs to rajkot
print(df[df.city=='rajkot'])
#Display students whose roll is bigger than 2.
print(df[df.roll>2])
#Display students' name who belongs to rajkot
print(df[['name']][df.city=='rajkot'])