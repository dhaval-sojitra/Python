#Creating data frame from .xlsx files
import pandas as pd
import xlrd
df=pd.read_excel("prod.xlsx")
print(df)