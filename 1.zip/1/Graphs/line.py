import matplotlib.pyplot as plt
years=['2023','2022','2021','2020','2019']
incr_pop=[70,45,60,75,30]
#Creating the line graph using plot()
plt.plot(years,incr_pop,color='red')
#Setting title and labels
plt.title('Population growth of India')
plt.xlabel('Years')
plt.ylabel('Increase_of_Population_in Lakhs')
#Display the line chart
plt.show()