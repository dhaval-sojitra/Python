#Creating data frame from Tuples
stud=[(1,'abc','rajkot'), (2,'cde','surat'), (3,'efg','goa'), (4,'ghi','diu'), (5,'ijk','vadodara')]
import pandas as pd
df=pd.DataFrame(stud, columns=['roll','name','city'])
print(df)