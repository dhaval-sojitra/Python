stud={'roll':[1,2,3,4,5],'name':['abc','cde','efg','ghi','ijk'],'city':['rajkot','surat','goa','diu','vadodara']}
import pandas as pd
df=pd.DataFrame(stud)
print(df)